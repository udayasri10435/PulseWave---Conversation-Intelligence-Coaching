import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '25mb' }));

// Server-side Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'PulseWave Conversation Intelligence Engine',
  });
});

// AI Call Analysis Endpoint
app.post('/api/analyze-call', async (req, res) => {
  try {
    const { transcript, title, repName, prospectCompany, prospectName, dealValue } = req.body;

    if (!transcript || !Array.isArray(transcript)) {
      return res.status(400).json({ error: 'Valid transcript array is required' });
    }

    const transcriptText = transcript
      .map((t: any) => `[${t.timestamp || '00:00'}] ${t.speaker}: ${t.text}`)
      .join('\n');

    const prompt = `You are the world's top revenue intelligence and sales coaching engine (like Gong or Chorus).
Analyze this B2B sales call transcript between sales rep "${repName || 'Sales Rep'}" and prospect "${prospectName || 'Prospect'}" at "${prospectCompany || 'Customer Company'}" with deal size "${dealValue || 'Enterprise'}".

Call Title: ${title || 'Sales Meeting'}
Transcript:
${transcriptText}

Generate a comprehensive Gong/Chorus-grade conversation intelligence breakdown in JSON format.
Follow this schema precisely:
{
  "executiveSummary": {
    "context": "Short 1-2 sentence executive overview of what was discussed",
    "customerPainPoints": ["Pain point 1", "Pain point 2"],
    "agreedNextSteps": ["Next step 1 with owner and timeline", "Next step 2"],
    "overallSentiment": "positive" | "cautious" | "skeptical" | "neutral"
  },
  "dealIntelligence": {
    "dealHealthScore": number (1-100),
    "healthStatus": "Healthy" | "At Risk" | "Critical",
    "healthRationale": "Why this score was awarded based on buyer commitment, budget clarity, and timeline",
    "meddicAnalysis": {
      "metrics": "Status of economic metrics identified",
      "economicBuyer": "Identified or missing",
      "decisionCriteria": "Key technical and commercial criteria",
      "decisionProcess": "Identified steps to signature",
      "identifyPain": "Core operational pain verified",
      "champion": "Champion identified and strength"
    },
    "competitorsMentioned": [
      {
        "name": "Competitor name (e.g. Clari, Gong, Salesforce, Chorus)",
        "context": "What was said about them",
        "sentiment": "favorable" | "unfavorable" | "neutral",
        "recommendedBattlecard": "Short 1-sentence sales positioning counter"
      }
    ],
    "objections": [
      {
        "type": "Pricing" | "Timing" | "Authority" | "Competitor" | "Technical / Security",
        "quote": "Exact or close quote from buyer expressing objection",
        "repHandling": "Summary of how rep addressed it",
        "repGrade": "A" | "B" | "C" | "D",
        "coachingTip": "Actionable Gong-style tip on how to handle this objection better"
      }
    ]
  },
  "salesRepCoaching": {
    "overallRepScore": number (1-100),
    "talkListenRatio": {
      "repPercentage": number,
      "prospectPercentage": number,
      "benchmarkComparison": "Optimal (40-45% rep)" | "Too High (Rep monologuing)" | "Too Low (Under-pitching)"
    },
    "monologueAnalysis": {
      "longestMonologueSeconds": number,
      "riskFlag": boolean,
      "advice": "Gong benchmark coaching advice"
    },
    "questionRate": {
      "questionsAskedByRep": number,
      "discoveryDepth": "Deep & consultative" | "Surface level" | "Needs more probing",
      "recommendation": "Coaching suggestion on question quality"
    },
    "patienceAndInterruption": {
      "interruptionCount": number,
      "patienceScore": number (1-10),
      "comment": "Advice on active listening and pauses"
    },
    "keyStrengths": ["Strength 1", "Strength 2"],
    "areasForImprovement": ["Improvement 1", "Improvement 2"]
  },
  "crmSyncPayload": {
    "targetStage": "Negotiation / Review" | "Proposal Delivered" | "Security Review" | "Closed Won" | "Needs Follow-up",
    "opportunityUpdate": "1-paragraph structured note formatted for Salesforce / HubSpot Activity Log",
    "nextTask": {
      "subject": "Clear task subject",
      "dueDateDaysFromNow": 2,
      "priority": "High" | "Medium"
    },
    "customFields": {
      "Economic_Buyer_Involved__c": boolean,
      "Competitor_Threat__c": "High" | "Medium" | "Low" | "None",
      "Forecast_Category__c": "Commit" | "Best Case" | "Pipeline" | "Omitted"
    }
  }
}
Respond ONLY with the JSON object, no Markdown code blocks or wrapping text.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (error: any) {
    console.error('Call analysis error:', error);
    res.status(500).json({
      error: 'Failed to analyze call with AI',
      message: error?.message || 'Internal error',
    });
  }
});

// AI Follow-up Email Generator Endpoint
app.post('/api/generate-email', async (req, res) => {
  try {
    const {
      prospectName,
      prospectCompany,
      repName,
      tone,
      actionItems,
      objections,
      keyHighlights,
    } = req.body;

    const prompt = `You are an elite enterprise B2B sales copywriter and conversation intelligence assistant.
Write a high-converting follow-up email from sales executive "${repName || 'Account Executive'}" to prospect "${prospectName || 'Client'}" at "${prospectCompany || 'Client Company'}".

Selected Tone: ${tone || 'Executive Brief (Punchy, direct, C-suite friendly)'}
Key Highlights discussed: ${JSON.stringify(keyHighlights || [])}
Action Items agreed: ${JSON.stringify(actionItems || [])}
Objections or questions to address: ${JSON.stringify(objections || [])}

Requirements:
- Professional, crisp, zero fluff or AI clichés like "I hope this email finds you well".
- Structure:
  1. Subject line (compelling, referencing specific company outcome)
  2. 1-sentence value recap
  3. Bullet points of key decisions & agreed action items with clear owners
  4. Addressing the main concern/objection proactively
  5. Clear, frictionless call-to-action for next meeting

Respond in JSON format:
{
  "subject": "Subject line here",
  "body": "Formatted email text (with newlines)",
  "executiveTip": "Why this email format wins deals according to Gong data"
}
Respond ONLY with JSON.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (error: any) {
    console.error('Follow-up email error:', error);
    res.status(500).json({
      error: 'Failed to generate email',
      message: error?.message || 'Internal error',
    });
  }
});

// CRM Push Simulation & Two-Way Sync Endpoint
app.post('/api/crm/push', async (req, res) => {
  try {
    const { crmType, callId, dealId, payload } = req.body;
    // Simulate real CRM push with enterprise transaction latency and generated IDs
    const syncId = `CRM-SYNC-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const syncTime = new Date().toISOString();

    res.json({
      success: true,
      syncId,
      crm: crmType || 'Salesforce Enterprise',
      syncedAt: syncTime,
      callId,
      dealId,
      activityLogId: `00T${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      taskCreated: payload?.nextTask?.subject || 'Follow up with executive team',
      opportunityStage: payload?.targetStage || 'Negotiation / Review',
      message: `Successfully synchronized call transcript, AI executive brief, and action items to ${crmType || 'Salesforce'}.`,
    });
  } catch (error: any) {
    res.status(500).json({ error: 'CRM synchronization failed' });
  }
});

// Audio / Note Transcription Endpoint
app.post('/api/transcribe-notes', async (req, res) => {
  try {
    const { rawAudioOrNotes, context } = req.body;

    const prompt = `You are a real-time sales transcription and speaker diarization engine.
Take these raw spoken notes or live captured text from a sales meeting and organize them into speaker-diarized transcript turns with timestamps and sentiment tags.

Context: ${context || 'Sales meeting between Rep and Prospect'}
Raw text/notes:
${rawAudioOrNotes}

Return a JSON array of transcript objects:
[
  {
    "id": "turn-1",
    "timestamp": "00:15",
    "seconds": 15,
    "speaker": "Sarah Chen (Account Exec)" or "David Miller (VP Eng)",
    "speakerRole": "rep" or "prospect",
    "text": "Cleaned up spoken turn",
    "sentiment": "positive" | "neutral" | "skeptical" | "curious",
    "topics": ["Pricing", "Security", "Architecture"],
    "objection": false
  }
]
Respond ONLY with JSON array.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    res.json({ turns: parsed });
  } catch (error: any) {
    res.status(500).json({ error: 'Transcription failed', message: error?.message });
  }
});

// Configure Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`PulseWave Conversation Intelligence running on port ${PORT}`);
  });
}

startServer();
