export type SpeakerRole = 'rep' | 'prospect' | 'other';

export interface TranscriptTurn {
  id: string;
  speaker: string;
  speakerRole: SpeakerRole;
  timestamp: string; // e.g. "01:24"
  seconds: number;
  text: string;
  sentiment: 'positive' | 'neutral' | 'skeptical' | 'hesitant';
  topics: string[];
  objection?: boolean;
  objectionType?: 'Pricing' | 'Timing' | 'Competitor' | 'Authority' | 'Technical / Security';
  coachingNote?: string;
  bookmarked?: boolean;
}

export interface ObjectionItem {
  type: 'Pricing' | 'Timing' | 'Authority' | 'Competitor' | 'Technical / Security';
  quote: string;
  repHandling: string;
  repGrade: 'A' | 'B' | 'C' | 'D';
  coachingTip: string;
}

export interface CompetitorItem {
  name: string;
  context: string;
  sentiment: 'favorable' | 'unfavorable' | 'neutral';
  recommendedBattlecard: string;
}

export interface MeddicAnalysis {
  metrics: string;
  economicBuyer: string;
  decisionCriteria: string;
  decisionProcess: string;
  identifyPain: string;
  champion: string;
}

export interface DealIntelligence {
  dealHealthScore: number; // 1-100
  healthStatus: 'Healthy' | 'At Risk' | 'Critical';
  healthRationale: string;
  meddicAnalysis: MeddicAnalysis;
  competitorsMentioned: CompetitorItem[];
  objections: ObjectionItem[];
}

export interface RepCoaching {
  overallRepScore: number;
  talkListenRatio: {
    repPercentage: number;
    prospectPercentage: number;
    benchmarkComparison: string;
  };
  monologueAnalysis: {
    longestMonologueSeconds: number;
    riskFlag: boolean;
    advice: string;
  };
  questionRate: {
    questionsAskedByRep: number;
    discoveryDepth: string;
    recommendation: string;
  };
  patienceAndInterruption: {
    interruptionCount: number;
    patienceScore: number;
    comment: string;
  };
  keyStrengths: string[];
  areasForImprovement: string[];
}

export interface CrmSyncPayload {
  targetStage: string;
  opportunityUpdate: string;
  nextTask: {
    subject: string;
    dueDateDaysFromNow: number;
    priority: 'High' | 'Medium' | 'Low';
  };
  customFields: {
    Economic_Buyer_Involved__c: boolean;
    Competitor_Threat__c: 'High' | 'Medium' | 'Low' | 'None';
    Forecast_Category__c: 'Commit' | 'Best Case' | 'Pipeline' | 'Omitted';
  };
}

export interface ExecutiveSummary {
  context: string;
  customerPainPoints: string[];
  agreedNextSteps: string[];
  overallSentiment: 'positive' | 'cautious' | 'skeptical' | 'neutral';
}

export interface CallRecord {
  id: string;
  title: string;
  prospectCompany: string;
  prospectName: string;
  prospectRole: string;
  repName: string;
  repAvatar: string;
  dealValue: string;
  stage: string;
  date: string;
  durationSeconds: number;
  durationFormatted: string;
  audioUrl?: string; // real audio file or generated synth
  isCustomUpload?: boolean;
  transcript: TranscriptTurn[];
  executiveSummary: ExecutiveSummary;
  dealIntelligence: DealIntelligence;
  salesRepCoaching: RepCoaching;
  crmSyncPayload: CrmSyncPayload;
  syncedCrm?: {
    crmName: string;
    syncedAt: string;
    syncId: string;
  };
}

export interface DealPipelineItem {
  id: string;
  dealName: string;
  company: string;
  value: string;
  stage: string;
  repName: string;
  healthScore: number;
  healthStatus: 'Healthy' | 'At Risk' | 'Critical';
  primaryRisk: string;
  lastCallDate: string;
  nextStep: string;
  competitor: string | null;
}

export interface RepScorecard {
  repName: string;
  role: string;
  avatar: string;
  dealsWonCount: number;
  winRate: number; // percentage e.g. 38%
  avgTalkListen: number; // rep talk % e.g. 43%
  avgQuestionsPerCall: number;
  monologueRiskFrequency: string; // e.g. "Low (12%)"
  patienceRating: number; // out of 10
  coachTip: string;
}
