import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Bookmark,
  Share2,
  Copy,
  Check,
  AlertCircle,
  Sparkles,
  ArrowDownCircle,
  Filter,
} from 'lucide-react';
import { TranscriptTurn } from '../types';

interface TranscriptViewerProps {
  transcript: TranscriptTurn[];
  currentTime: number;
  onSeek: (seconds: number) => void;
  repName: string;
}

export const TranscriptViewer: React.FC<TranscriptViewerProps> = ({
  transcript,
  currentTime,
  onSeek,
  repName,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('All');
  const [autoScroll, setAutoScroll] = useState(true);
  const [copiedTurnId, setCopiedTurnId] = useState<string | null>(null);
  const activeTurnRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Extract all unique topics
  const allTopics = React.useMemo(() => {
    const set = new Set<string>();
    transcript.forEach((t) => t.topics.forEach((top) => set.add(top)));
    return ['All', ...Array.from(set)];
  }, [transcript]);

  // Active turn based on current audio playback
  const activeTurn = transcript.reduce<TranscriptTurn | null>((acc, turn) => {
    if (currentTime >= turn.seconds) {
      return turn;
    }
    return acc;
  }, null) || transcript[0];

  // Auto-scroll to active turn if autoScroll is enabled
  useEffect(() => {
    if (autoScroll && activeTurnRef.current && containerRef.current) {
      activeTurnRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [activeTurn?.id, autoScroll]);

  // Filtered turns
  const filteredTurns = transcript.filter((turn) => {
    const matchesSearch =
      searchQuery === '' ||
      turn.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      turn.speaker.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTopic =
      selectedTopic === 'All' || turn.topics.includes(selectedTopic);
    return matchesSearch && matchesTopic;
  });

  const handleCopyTurn = (turn: TranscriptTurn) => {
    navigator.clipboard.writeText(`[${turn.timestamp}] ${turn.speaker}: ${turn.text}`);
    setCopiedTurnId(turn.id);
    setTimeout(() => setCopiedTurnId(null), 2000);
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <mark key={i} className="bg-yellow-400/30 text-yellow-200 px-0.5 rounded">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
      {/* Top Search & Filter Bar */}
      <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-col gap-2.5">
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search transcript by keywords (e.g. pricing, Clari, SLA)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500/60 focus:ring-1 focus:ring-indigo-500/20"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                autoScroll
                  ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-300'
              }`}
              title="Automatically follow speaking playback"
            >
              <ArrowDownCircle className={`w-3.5 h-3.5 ${autoScroll ? 'animate-bounce' : ''}`} />
              <span className="hidden sm:inline">Follow audio</span>
            </button>
          </div>
        </div>

        {/* Topic Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-[11px] text-slate-500 uppercase font-mono mr-1">Topics:</span>
          {allTopics.slice(0, 7).map((topic) => (
            <button
              key={topic}
              onClick={() => setSelectedTopic(topic)}
              className={`px-2.5 py-1 rounded-md whitespace-nowrap text-xs transition-colors ${
                selectedTopic === topic
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {topic}
            </button>
          ))}
        </div>
      </div>

      {/* Transcript Turns List */}
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto p-4 space-y-3.5 divide-y divide-slate-800/40"
      >
        {filteredTurns.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            No transcript matches for "{searchQuery}"
          </div>
        ) : (
          filteredTurns.map((turn) => {
            const isActive = activeTurn?.id === turn.id;
            const isRep = turn.speakerRole === 'rep';

            return (
              <div
                key={turn.id}
                ref={isActive ? activeTurnRef : null}
                className={`pt-3.5 transition-all rounded-lg p-2.5 ${
                  isActive
                    ? 'bg-indigo-950/30 border border-indigo-500/30 shadow-sm'
                    : 'hover:bg-slate-800/30'
                }`}
              >
                {/* Speaker Line */}
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    {/* Timestamp seek button */}
                    <button
                      onClick={() => onSeek(turn.seconds)}
                      className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-slate-800/80 hover:bg-indigo-600 hover:text-white text-indigo-400 transition-colors"
                      title="Jump audio to this moment"
                    >
                      {turn.timestamp}
                    </button>

                    {/* Speaker name */}
                    <span
                      className={`text-xs font-semibold ${
                        isRep ? 'text-indigo-300' : 'text-emerald-300'
                      }`}
                    >
                      {turn.speaker}
                    </span>

                    {/* Clean unboxed metadata separator */}
                    <span className="text-slate-600 text-xs">·</span>

                    {/* Sentiment metadata */}
                    <span
                      className={`text-[11px] capitalize ${
                        turn.sentiment === 'positive'
                          ? 'text-emerald-400'
                          : turn.sentiment === 'skeptical'
                          ? 'text-amber-400'
                          : turn.sentiment === 'hesitant'
                          ? 'text-rose-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {turn.sentiment}
                    </span>
                  </div>

                  {/* Actions: Copy snippet */}
                  <div className="flex items-center gap-1 opacity-80 hover:opacity-100">
                    <button
                      onClick={() => handleCopyTurn(turn)}
                      className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                      title="Copy quote with timestamp"
                    >
                      {copiedTurnId === turn.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Spoken Text */}
                <p className="text-xs sm:text-[13px] text-slate-200 leading-relaxed pl-1">
                  {highlightMatch(turn.text, searchQuery)}
                </p>

                {/* Objection Callout if detected */}
                {turn.objection && (
                  <div className="mt-2.5 p-2 bg-amber-950/40 border border-amber-500/30 rounded-md flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                    <div className="text-xs">
                      <span className="font-semibold text-amber-300">
                        {turn.objectionType || 'Objection'} Detected:
                      </span>{' '}
                      <span className="text-amber-200/90 text-[11px]">
                        {turn.coachingNote ||
                          'Buyer signaled hesitation or comparison. Monitor rep counter.'}
                      </span>
                    </div>
                  </div>
                )}

                {/* Topics Tagline */}
                {turn.topics.length > 0 && (
                  <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-500">
                    <span className="font-mono">Trackers:</span>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {turn.topics.map((t, idx) => (
                        <span key={idx} className="text-slate-400">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
