import React, { useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Award,
  Send,
  Copy,
  Check,
  RefreshCw,
  TrendingUp,
  Clock,
  HelpCircle,
  Swords,
  Layers,
  Database,
  Mail,
  Flame,
} from 'lucide-react';
import { CallRecord } from '../types';

interface SidecarIntelligenceProps {
  call: CallRecord;
  onUpdateCall: (updatedCall: CallRecord) => void;
  onSeek: (seconds: number) => void;
}

export const SidecarIntelligence: React.FC<SidecarIntelligenceProps> = ({
  call,
  onUpdateCall,
  onSeek,
}) => {
  const [activeTab, setActiveTab] = useState<'deal' | 'coaching' | 'crm'>('deal');
  const [emailTone, setEmailTone] = useState<'Executive Brief' | 'Urgency & Closing' | 'Technical Architecture' | 'Collaborative'>('Executive Brief');
  const [generatedEmail, setGeneratedEmail] = useState<{
    subject: string;
    body: string;
    executiveTip?: string;
  } | null>(null);
  const [isGeneratingEmail, setIsGeneratingEmail] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // CRM Sync States
  const [selectedCrm, setSelectedCrm] = useState<'Salesforce' | 'HubSpot' | 'Pipedrive'>('Salesforce');
  const [isSyncingCrm, setIsSyncingCrm] = useState(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);

  // Re-run AI Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const { dealIntelligence, salesRepCoaching, crmSyncPayload, executiveSummary } = call;

  // Handler for Re-running AI analysis via Gemini API
  const handleReanalyzeCall = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/analyze-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: call.transcript,
          title: call.title,
          repName: call.repName,
          prospectCompany: call.prospectCompany,
          prospectName: call.prospectName,
          dealValue: call.dealValue,
        }),
      });

      if (!res.ok) throw new Error('Analysis failed');
      const data = await res.json();

      onUpdateCall({
        ...call,
        executiveSummary: data.executiveSummary || call.executiveSummary,
        dealIntelligence: data.dealIntelligence || call.dealIntelligence,
        salesRepCoaching: data.salesRepCoaching || call.salesRepCoaching,
        crmSyncPayload: data.crmSyncPayload || call.crmSyncPayload,
      });
    } catch (err) {
      console.error('Error re-analyzing call:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handler for generating AI follow-up email via Gemini API
  const handleGenerateEmail = async () => {
    setIsGeneratingEmail(true);
    try {
      const res = await fetch('/api/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          repName: call.repName,
          prospectName: call.prospectName,
          prospectCompany: call.prospectCompany,
          tone: emailTone,
          keyHighlights: executiveSummary.customerPainPoints,
          actionItems: executiveSummary.agreedNextSteps,
          objections: dealIntelligence.objections.map((o) => o.quote),
        }),
      });

      if (!res.ok) throw new Error('Email generation failed');
      const data = await res.json();
      setGeneratedEmail(data);
    } catch (err) {
      console.error('Email generation error:', err);
    } finally {
      setIsGeneratingEmail(false);
    }
  };

  // Handler for pushing to CRM via backend
  const handlePushToCrm = async () => {
    setIsSyncingCrm(true);
    setSyncSuccessMsg(null);
    try {
      const res = await fetch('/api/crm/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          crmType: selectedCrm,
          callId: call.id,
          dealId: `OPP-${call.prospectCompany.substring(0, 4).toUpperCase()}-2026`,
          payload: crmSyncPayload,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSyncSuccessMsg(`Synced to ${selectedCrm} (ID: ${data.syncId})`);
        onUpdateCall({
          ...call,
          syncedCrm: {
            crmName: selectedCrm,
            syncedAt: 'Just now',
            syncId: data.syncId,
          },
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSyncingCrm(false);
    }
  };

  const handleCopyEmail = () => {
    if (!generatedEmail) return;
    navigator.clipboard.writeText(`Subject: ${generatedEmail.subject}\n\n${generatedEmail.body}`);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
      {/* Tab Switcher Header */}
      <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('deal')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeTab === 'deal'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Deal Health</span>
          </button>
          <button
            onClick={() => setActiveTab('coaching')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeTab === 'coaching'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Rep Coaching</span>
          </button>
          <button
            onClick={() => setActiveTab('crm')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
              activeTab === 'crm'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>CRM & Follow-up</span>
          </button>
        </div>

        {/* Refresh AI Analysis Button */}
        <button
          onClick={handleReanalyzeCall}
          disabled={isAnalyzing}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-300 hover:text-white bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/30 rounded-lg transition-colors disabled:opacity-50"
          title="Re-run deep AI conversation intelligence analysis"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">AI Refresh</span>
        </button>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* ================= TAB 1: DEAL HEALTH ================= */}
        {activeTab === 'deal' && (
          <div className="space-y-4">
            {/* Deal Health Banner */}
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg flex items-center justify-between gap-4">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-mono">
                  Deal Health Status
                </span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`text-xl font-bold ${
                      dealIntelligence.dealHealthScore >= 80
                        ? 'text-emerald-400'
                        : dealIntelligence.dealHealthScore >= 60
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {dealIntelligence.dealHealthScore}/100
                  </span>
                  <span className="text-xs text-slate-300 font-medium">
                    · {dealIntelligence.healthStatus}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {dealIntelligence.healthRationale}
                </p>
              </div>

              <div className="shrink-0 w-14 h-14 rounded-full bg-slate-900 border-2 border-slate-700 flex items-center justify-center">
                <span className="text-xs font-mono font-bold text-slate-200">
                  {call.dealValue}
                </span>
              </div>
            </div>

            {/* Executive Summary */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                  Executive Brief
                </h3>
                <span className="text-[11px] text-slate-400 capitalize">
                  Sentiment: {executiveSummary.overallSentiment}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {executiveSummary.context}
              </p>

              {/* Customer Pain Points */}
              <div className="pt-2 border-t border-slate-800/60">
                <h4 className="text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Customer Pain & Requirements
                </h4>
                <ul className="space-y-1">
                  {executiveSummary.customerPainPoints.map((pain, i) => (
                    <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-indigo-400 mt-0.5">•</span>
                      <span>{pain}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Agreed Next Steps */}
              <div className="pt-2 border-t border-slate-800/60">
                <h4 className="text-[11px] font-mono text-slate-400 uppercase mb-1">
                  Agreed Action Items
                </h4>
                <ul className="space-y-1.5">
                  {executiveSummary.agreedNextSteps.map((step, i) => (
                    <li key={i} className="text-xs text-emerald-300/90 flex items-start gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Objections Radar */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                  Objections & Battlecards
                </h3>
                <span className="text-[11px] text-slate-400 font-mono">
                  {dealIntelligence.objections.length} detected
                </span>
              </div>

              {dealIntelligence.objections.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No hard objections detected.</p>
              ) : (
                dealIntelligence.objections.map((obj, i) => (
                  <div
                    key={i}
                    className="p-2.5 bg-slate-900/90 border border-slate-800 rounded-md space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-amber-400">
                        {obj.type} Objection
                      </span>
                      <span className="font-mono text-[11px] text-indigo-400">
                        Rep Grade: {obj.repGrade}
                      </span>
                    </div>
                    <blockquote className="italic text-slate-300 pl-2 border-l-2 border-amber-500/50">
                      "{obj.quote}"
                    </blockquote>
                    <p className="text-slate-400 text-[11px]">
                      <strong className="text-slate-300">How Rep Handled:</strong> {obj.repHandling}
                    </p>
                    <div className="p-2 bg-indigo-950/30 rounded border border-indigo-500/20 text-indigo-200 text-[11px]">
                      <strong>Coaching Playbook:</strong> {obj.coachingTip}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Competitor Mentions */}
            {dealIntelligence.competitorsMentioned.length > 0 && (
              <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-2">
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wide flex items-center gap-1.5">
                  <Swords className="w-3.5 h-3.5 text-rose-400" />
                  <span>Competitor Intelligence</span>
                </h3>
                {dealIntelligence.competitorsMentioned.map((comp, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-900 border border-slate-800 rounded-md space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-rose-300">{comp.name}</span>
                      <span className="text-[10px] text-slate-400 capitalize">
                        Buyer stance: {comp.sentiment}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">{comp.context}</p>
                    <p className="text-[11px] text-indigo-300 pt-1 border-t border-slate-800/60">
                      <strong>Battlecard Counter:</strong> {comp.recommendedBattlecard}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* MEDDIC Grid */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-2">
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                MEDDIC Deal Qualification
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-2 bg-slate-900 rounded border border-slate-800/80">
                  <span className="text-[10px] font-mono text-indigo-400 block">Metrics</span>
                  <span className="text-slate-300 text-[11px]">{dealIntelligence.meddicAnalysis.metrics}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800/80">
                  <span className="text-[10px] font-mono text-indigo-400 block">Economic Buyer</span>
                  <span className="text-slate-300 text-[11px]">{dealIntelligence.meddicAnalysis.economicBuyer}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800/80">
                  <span className="text-[10px] font-mono text-indigo-400 block">Decision Criteria</span>
                  <span className="text-slate-300 text-[11px]">{dealIntelligence.meddicAnalysis.decisionCriteria}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800/80">
                  <span className="text-[10px] font-mono text-indigo-400 block">Champion</span>
                  <span className="text-slate-300 text-[11px]">{dealIntelligence.meddicAnalysis.champion}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 2: REP COACHING ================= */}
        {activeTab === 'coaching' && (
          <div className="space-y-4">
            {/* Rep Score Banner */}
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-mono">
                  Rep Conversation Score
                </span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-2xl font-bold text-indigo-400">
                    {salesRepCoaching.overallRepScore}/100
                  </span>
                  <span className="text-xs text-slate-300 font-medium">
                    · {call.repName}
                  </span>
                </div>
              </div>
              <Award className="w-8 h-8 text-indigo-400/80" />
            </div>

            {/* Talk:Listen Ratio Gauge */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">Talk:Listen Ratio</span>
                <span className="text-slate-400 font-mono text-[11px]">
                  Benchmark: 43% Rep / 57% Buyer
                </span>
              </div>

              {/* Dual Colored Bar */}
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  style={{ width: `${salesRepCoaching.talkListenRatio.repPercentage}%` }}
                  className="bg-indigo-500 flex items-center justify-center text-[10px] text-white font-mono font-bold"
                >
                  {salesRepCoaching.talkListenRatio.repPercentage}% Rep
                </div>
                <div
                  style={{ width: `${salesRepCoaching.talkListenRatio.prospectPercentage}%` }}
                  className="bg-emerald-500 flex items-center justify-center text-[10px] text-white font-mono font-bold"
                >
                  {salesRepCoaching.talkListenRatio.prospectPercentage}% Buyer
                </div>
              </div>
              <p className="text-[11px] text-slate-400">
                Evaluation: {salesRepCoaching.talkListenRatio.benchmarkComparison}
              </p>
            </div>

            {/* Monologue Analysis */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  Longest Monologue
                </span>
                <span className="font-mono text-indigo-300 font-bold">
                  {salesRepCoaching.monologueAnalysis.longestMonologueSeconds}s
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {salesRepCoaching.monologueAnalysis.advice}
              </p>
              <div className="text-[11px] text-slate-500">
                Gong research shows monologues over 2.5 mins (150s) decrease deal close rates by 34%.
              </div>
            </div>

            {/* Question Rate & Discovery */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                  Discovery Question Rate
                </span>
                <span className="font-mono text-cyan-300 font-bold">
                  {salesRepCoaching.questionRate.questionsAskedByRep} questions
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Depth: <strong className="text-slate-200">{salesRepCoaching.questionRate.discoveryDepth}</strong>
              </p>
              <p className="text-[11px] text-slate-400">
                {salesRepCoaching.questionRate.recommendation}
              </p>
            </div>

            {/* Strengths & Improvement Areas */}
            <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-lg space-y-3">
              <div>
                <h4 className="text-[11px] font-mono text-emerald-400 uppercase mb-1">
                  Observed Strengths
                </h4>
                <ul className="space-y-1">
                  {salesRepCoaching.keyStrengths.map((str, i) => (
                    <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-emerald-400 mt-0.5">•</span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2 border-t border-slate-800/60">
                <h4 className="text-[11px] font-mono text-amber-400 uppercase mb-1">
                  Manager Coaching Focus
                </h4>
                <ul className="space-y-1">
                  {salesRepCoaching.areasForImprovement.map((imp, i) => (
                    <li key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                      <span className="text-amber-400 mt-0.5">•</span>
                      <span>{imp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: CRM SYNC & FOLLOW-UP ================= */}
        {activeTab === 'crm' && (
          <div className="space-y-4">
            {/* CRM Destination & Sync Box */}
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                  CRM Two-Way Sync
                </span>
                <select
                  value={selectedCrm}
                  onChange={(e) => setSelectedCrm(e.target.value as any)}
                  className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-2 py-1 focus:outline-none"
                >
                  <option value="Salesforce">Salesforce Enterprise</option>
                  <option value="HubSpot">HubSpot Sales Hub</option>
                  <option value="Pipedrive">Pipedrive CRM</option>
                </select>
              </div>

              {/* Mapped Fields Preview */}
              <div className="space-y-2 text-xs">
                <div className="p-2 bg-slate-900 rounded border border-slate-800 flex justify-between">
                  <span className="text-slate-400">Target Stage:</span>
                  <span className="text-indigo-400 font-semibold">{crmSyncPayload.targetStage}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800 flex justify-between">
                  <span className="text-slate-400">Next Task:</span>
                  <span className="text-slate-200 truncate max-w-[200px]" title={crmSyncPayload.nextTask.subject}>
                    {crmSyncPayload.nextTask.subject}
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block mb-1">Opportunity Activity Note:</span>
                  <p className="text-[11px] text-slate-300 leading-relaxed font-mono">
                    {crmSyncPayload.opportunityUpdate}
                  </p>
                </div>
              </div>

              {/* Sync Button & Status */}
              <div className="flex items-center gap-3 pt-1">
                <button
                  onClick={handlePushToCrm}
                  disabled={isSyncingCrm}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-sm disabled:opacity-50"
                >
                  <Database className={`w-3.5 h-3.5 ${isSyncingCrm ? 'animate-bounce' : ''}`} />
                  <span>{isSyncingCrm ? 'Syncing...' : `Push to ${selectedCrm}`}</span>
                </button>
              </div>

              {syncSuccessMsg && (
                <div className="p-2 bg-emerald-950/50 border border-emerald-500/40 rounded text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{syncSuccessMsg}</span>
                </div>
              )}
            </div>

            {/* AI Follow-Up Email Generator */}
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wide flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-indigo-400" />
                  AI Follow-Up Email
                </span>
                <span className="text-[10px] text-indigo-400 font-mono">Gong-proven format</span>
              </div>

              {/* Tone Selector */}
              <div className="flex items-center gap-1 flex-wrap text-xs">
                {(['Executive Brief', 'Urgency & Closing', 'Technical Architecture', 'Collaborative'] as const).map(
                  (tone) => (
                    <button
                      key={tone}
                      onClick={() => setEmailTone(tone)}
                      className={`px-2 py-1 rounded text-[11px] transition-colors ${
                        emailTone === tone
                          ? 'bg-indigo-600 text-white font-medium'
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tone}
                    </button>
                  )
                )}
              </div>

              <button
                onClick={handleGenerateEmail}
                disabled={isGeneratingEmail}
                className="w-full flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-500/30 rounded-lg transition-colors disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isGeneratingEmail ? 'animate-spin' : ''}`} />
                <span>{isGeneratingEmail ? 'Drafting Follow-up Email...' : 'Generate High-Converting Email'}</span>
              </button>

              {/* Generated Email Output */}
              {generatedEmail && (
                <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                  <div className="p-2 bg-slate-900 rounded border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase font-mono block">
                      Subject
                    </span>
                    <span className="font-semibold text-slate-100">{generatedEmail.subject}</span>
                  </div>

                  <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase font-mono block mb-1">
                      Body
                    </span>
                    <div className="text-slate-200 text-xs whitespace-pre-line leading-relaxed font-sans">
                      {generatedEmail.body}
                    </div>
                  </div>

                  {generatedEmail.executiveTip && (
                    <p className="text-[11px] text-indigo-300 italic">
                      Tip: {generatedEmail.executiveTip}
                    </p>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyEmail}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
                    >
                      {copiedEmail ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedEmail ? 'Copied!' : 'Copy to Clipboard'}</span>
                    </button>
                    <a
                      href={`mailto:?subject=${encodeURIComponent(generatedEmail.subject)}&body=${encodeURIComponent(generatedEmail.body)}`}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs rounded transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Open in Mail</span>
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
