import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Bookmark,
  Sparkles,
  X,
  Volume2,
  Radio,
  FileText,
  Monitor,
  CheckCircle,
} from 'lucide-react';
import { CallRecord, TranscriptTurn } from '../types';
import { formatSeconds } from '../utils/audioEngine';

interface LiveRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCallRecorded: (newCall: CallRecord) => void;
}

export const LiveRecorderModal: React.FC<LiveRecorderModalProps> = ({
  isOpen,
  onClose,
  onCallRecorded,
}) => {
  const [sourceType, setSourceType] = useState<'mic' | 'screen'>('mic');
  const [isRecording, setIsRecording] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const [liveNotes, setLiveNotes] = useState('');
  const [companyName, setCompanyName] = useState('Apollo Health');
  const [prospectName, setProspectName] = useState('Dr. Marcus Green');
  const [repName, setRepName] = useState('Sarah Chen');
  const [dealValue, setDealValue] = useState('$95,000');
  const [isProcessing, setIsProcessing] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  if (!isOpen) return null;

  const startVisualizer = (stream: MediaStream) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const draw = () => {
        if (!canvasRef.current) return;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        analyser.getByteFrequencyData(dataArray);

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const barWidth = (canvas.width / bufferLength) * 2;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = (dataArray[i] / 255) * canvas.height;
          ctx.fillStyle = `rgb(99, 102, 241)`;
          ctx.fillRect(x, canvas.height - barHeight, barWidth - 1, barHeight);
          x += barWidth + 1;
        }

        animationFrameRef.current = requestAnimationFrame(draw);
      };

      draw();
    } catch (err) {
      console.warn('AudioContext visualization not available:', err);
    }
  };

  const handleStartRecording = async () => {
    try {
      audioChunksRef.current = [];
      let stream: MediaStream;

      if (sourceType === 'mic') {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } else {
        stream = await navigator.mediaDevices.getDisplayMedia({
          audio: true,
          video: true,
        });
      }

      startVisualizer(stream);

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setElapsedSeconds(0);
      setBookmarks([]);

      timerRef.current = window.setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Error starting recording:', err);
      // Fallback demo simulation if browser permissions are denied
      setIsRecording(true);
      timerRef.current = window.setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    }
  };

  const handleAddBookmark = () => {
    setBookmarks((prev) => [...prev, elapsedSeconds]);
  };

  const handleStopRecording = async () => {
    setIsProcessing(true);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
    }

    let recordedAudioUrl = '';
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((t) => t.stop());
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      recordedAudioUrl = URL.createObjectURL(audioBlob);
    }

    const durationSec = Math.max(12, elapsedSeconds);

    // Build synthesized transcript turns based on the live call
    const simulatedTurns: TranscriptTurn[] = [
      {
        id: `live-1`,
        speaker: repName,
        speakerRole: 'rep',
        timestamp: '00:03',
        seconds: 3,
        text: `Thanks for joining Dr. Green. We are excited to present our automated clinical conversation intelligence pipeline for ${companyName}.`,
        sentiment: 'positive',
        topics: ['Agenda', 'Introduction'],
      },
      {
        id: `live-2`,
        speaker: prospectName,
        speakerRole: 'prospect',
        timestamp: '00:15',
        seconds: 15,
        text: `Good to meet you Sarah. Our biggest question is HIPAA compliance and EHR integration latency. Can your models operate with zero data retention on patient telemetry?`,
        sentiment: 'skeptical',
        topics: ['HIPAA', 'Security', 'Compliance'],
        objection: true,
        objectionType: 'Technical / Security',
        coachingNote: 'Critical healthcare security objection. Provide immediate regulatory assurances.',
      },
      {
        id: `live-3`,
        speaker: repName,
        speakerRole: 'rep',
        timestamp: '00:34',
        seconds: 34,
        text: `100%. We have full BAA executed with Tier 1 hospitals, and all audio streams can be set to immediate ephemerality with zero model training.`,
        sentiment: 'positive',
        topics: ['BAA', 'HIPAA', 'Compliance'],
      },
      {
        id: `live-4`,
        speaker: prospectName,
        speakerRole: 'prospect',
        timestamp: '00:52',
        seconds: 52,
        text: `That resolves our compliance hurdle. If you can get our team a 30-day sandbox pilot by next Tuesday, I will schedule the review with our clinical committee.`,
        sentiment: 'positive',
        topics: ['Pilot', 'Next Steps'],
      },
    ];

    try {
      // Analyze with Gemini
      const analysisRes = await fetch('/api/analyze-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: simulatedTurns,
          title: `${companyName} — Live Meeting & Clinical Review`,
          repName,
          prospectCompany: companyName,
          prospectName,
          dealValue,
        }),
      });

      const analysisData = await analysisRes.json();

      const newCallRecord: CallRecord = {
        id: `call-live-${Date.now()}`,
        title: `${companyName} — Live Meeting Review`,
        prospectCompany: companyName,
        prospectName,
        prospectRole: 'Executive Lead',
        repName,
        repAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=160&q=80',
        dealValue,
        stage: 'Proposal Delivered',
        date: 'Just now',
        durationSeconds: durationSec,
        durationFormatted: formatSeconds(durationSec),
        audioUrl: recordedAudioUrl,
        isCustomUpload: true,
        transcript: simulatedTurns,
        executiveSummary: analysisData.executiveSummary || {
          context: `Live conversation recorded with ${prospectName} at ${companyName}.`,
          customerPainPoints: ['HIPAA compliance', 'Zero retention on patient data'],
          agreedNextSteps: ['Deliver 30-day sandbox pilot by next Tuesday'],
          overallSentiment: 'positive',
        },
        dealIntelligence: analysisData.dealIntelligence || {
          dealHealthScore: 88,
          healthStatus: 'Healthy',
          healthRationale: 'HIPAA objection resolved promptly. Clinical committee review committed.',
          meddicAnalysis: {
            metrics: 'Zero retention EHR stream',
            economicBuyer: prospectName,
            decisionCriteria: 'HIPAA, BAA, sandbox performance',
            decisionProcess: 'Sandbox test -> Clinical committee sign-off',
            identifyPain: 'EHR compliance backlog',
            champion: prospectName,
          },
          competitorsMentioned: [],
          objections: [
            {
              type: 'Technical / Security',
              quote: 'Can your models operate with zero data retention on patient telemetry?',
              repHandling: 'Affirmed BAA compliance and immediate audio ephemerality.',
              repGrade: 'A',
              coachingTip: 'Strong and immediate compliance reassurance.',
            },
          ],
        },
        salesRepCoaching: analysisData.salesRepCoaching || {
          overallRepScore: 91,
          talkListenRatio: {
            repPercentage: 45,
            prospectPercentage: 55,
            benchmarkComparison: 'Optimal (40-45% rep)',
          },
          monologueAnalysis: {
            longestMonologueSeconds: 22,
            riskFlag: false,
            advice: 'Concise, clear answers.',
          },
          questionRate: {
            questionsAskedByRep: 2,
            discoveryDepth: 'Direct consulting',
            recommendation: 'Good pace.',
          },
          patienceAndInterruption: {
            interruptionCount: 0,
            patienceScore: 9.3,
            comment: 'Zero interruptions.',
          },
          keyStrengths: ['Regulatory fluency', 'Clear next steps'],
          areasForImprovement: ['Probe clinical committee members beforehand'],
        },
        crmSyncPayload: analysisData.crmSyncPayload || {
          targetStage: 'Proposal Delivered',
          opportunityUpdate: `Recorded live meeting with ${prospectName}. Addressed HIPAA questions. Sandbox setup scheduled for Tuesday.`,
          nextTask: {
            subject: 'Deliver 30-day sandbox pilot to Dr. Marcus Green',
            dueDateDaysFromNow: 3,
            priority: 'High',
          },
          customFields: {
            Economic_Buyer_Involved__c: true,
            Competitor_Threat__c: 'None',
            Forecast_Category__c: 'Best Case',
          },
        },
      };

      onCallRecorded(newCallRecord);
      onClose();
    } catch (e) {
      console.error('Processing live call error:', e);
      onClose();
    } finally {
      setIsProcessing(false);
      setIsRecording(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-red-500 animate-pulse" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Live Call & Meeting Recorder
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {/* Metadata Inputs */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Prospect Company
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                disabled={isRecording}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Prospect Name
              </label>
              <input
                type="text"
                value={prospectName}
                onChange={(e) => setProspectName(e.target.value)}
                disabled={isRecording}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Account Executive
              </label>
              <input
                type="text"
                value={repName}
                onChange={(e) => setRepName(e.target.value)}
                disabled={isRecording}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Deal Target Value
              </label>
              <input
                type="text"
                value={dealValue}
                onChange={(e) => setDealValue(e.target.value)}
                disabled={isRecording}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Audio Source Selector */}
          {!isRecording && (
            <div className="flex items-center gap-2 pt-1 text-xs">
              <span className="text-slate-400 font-mono text-[11px]">Audio Source:</span>
              <button
                type="button"
                onClick={() => setSourceType('mic')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors ${
                  sourceType === 'mic'
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Microphone</span>
              </button>
              <button
                type="button"
                onClick={() => setSourceType('screen')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs transition-colors ${
                  sourceType === 'screen'
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Screen / Tab Audio (Zoom / Meet)</span>
              </button>
            </div>
          )}

          {/* Live Waveform & Visualizer */}
          <div className="h-24 bg-slate-950 rounded-lg border border-slate-800 flex flex-col items-center justify-center p-3 relative overflow-hidden">
            {isRecording ? (
              <canvas
                ref={canvasRef}
                width={400}
                height={70}
                className="w-full h-full"
              />
            ) : (
              <div className="text-center text-xs text-slate-500 flex flex-col items-center gap-1">
                <Volume2 className="w-5 h-5 text-slate-600" />
                <span>Click "Start Recording" to capture audio stream</span>
              </div>
            )}

            {isRecording && (
              <div className="absolute top-2 right-3 flex items-center gap-2 text-xs font-mono font-bold text-red-400">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span>REC {formatSeconds(elapsedSeconds)}</span>
              </div>
            )}
          </div>

          {/* Live Call Notes & Bookmark Drops */}
          {isRecording && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono text-[11px]">
                  Live Key Points / Notes:
                </span>
                <button
                  type="button"
                  onClick={handleAddBookmark}
                  className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] transition-colors"
                >
                  <Bookmark className="w-3 h-3" />
                  <span>Drop Bookmark ({bookmarks.length})</span>
                </button>
              </div>
              <textarea
                rows={2}
                placeholder="Type quick meeting notes here during the call..."
                value={liveNotes}
                onChange={(e) => setLiveNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            Cancel
          </button>

          {!isRecording ? (
            <button
              onClick={handleStartRecording}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-red-600/30 transition-all"
            >
              <Mic className="w-4 h-4" />
              <span>Start Recording</span>
            </button>
          ) : (
            <button
              onClick={handleStopRecording}
              disabled={isProcessing}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
            >
              {isProcessing ? (
                <Sparkles className="w-4 h-4 animate-spin" />
              ) : (
                <Square className="w-4 h-4 fill-white" />
              )}
              <span>{isProcessing ? 'Analyzing with Gemini AI...' : 'Finish & Analyze'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
