import React, { useState } from 'react';
import {
  Layers,
  AlertTriangle,
  TrendingUp,
  ShieldAlert,
  CheckCircle,
  ExternalLink,
  Search,
  Filter,
} from 'lucide-react';
import { PIPELINE_DEALS } from '../data/mockCalls';
import { DealPipelineItem, CallRecord } from '../types';

interface DealPipelineViewProps {
  onSelectDealCall: (dealId: string) => void;
  calls: CallRecord[];
}

export const DealPipelineView: React.FC<DealPipelineViewProps> = ({
  onSelectDealCall,
  calls,
}) => {
  const [filterStatus, setFilterStatus] = useState<'All' | 'Healthy' | 'At Risk' | 'Critical'>('All');
  const [search, setSearch] = useState('');

  const filteredDeals = PIPELINE_DEALS.filter((deal) => {
    const matchesStatus = filterStatus === 'All' || deal.healthStatus === filterStatus;
    const matchesSearch =
      search === '' ||
      deal.company.toLowerCase().includes(search.toLowerCase()) ||
      deal.dealName.toLowerCase().includes(search.toLowerCase()) ||
      deal.repName.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const totalPipeline = '$545,000';
  const atRiskValue = '$210,000';
  const healthyDealsCount = PIPELINE_DEALS.filter((d) => d.healthStatus === 'Healthy').length;
  const atRiskCount = PIPELINE_DEALS.filter((d) => d.healthStatus !== 'Healthy').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
            Total Pipeline Value
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-white tracking-tight">{totalPipeline}</span>
            <span className="text-xs text-indigo-400 font-medium">5 active deals</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
            Pipeline at Risk
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-amber-400 tracking-tight">{atRiskValue}</span>
            <span className="text-xs text-amber-400/80 font-medium">{atRiskCount} deals flagged</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
            Avg Rep Talk Ratio
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-indigo-400 tracking-tight">44%</span>
            <span className="text-xs text-slate-400">Optimal (Benchmark: 43%)</span>
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
            Forecast Health
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-emerald-400 tracking-tight">
              {healthyDealsCount} / {PIPELINE_DEALS.length}
            </span>
            <span className="text-xs text-emerald-400/80 font-medium">Commit on track</span>
          </div>
        </div>
      </div>

      {/* Table Section with Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        {/* Table Controls */}
        <div className="p-4 bg-slate-900/90 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search deals, company, or rep..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <span className="text-[11px] font-mono text-slate-400 mr-1">Status:</span>
            {(['All', 'Healthy', 'At Risk'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status as any)}
                className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                  filterStatus === status
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/70 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
              <tr>
                <th className="px-4 py-3">Deal & Company</th>
                <th className="px-4 py-3">Value</th>
                <th className="px-4 py-3">Stage</th>
                <th className="px-4 py-3">Rep</th>
                <th className="px-4 py-3">Deal Health</th>
                <th className="px-4 py-3">Conversation Signals & Risks</th>
                <th className="px-4 py-3">Next Step</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredDeals.map((deal) => {
                const isHealthy = deal.healthStatus === 'Healthy';
                return (
                  <tr key={deal.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-semibold text-slate-200">{deal.dealName}</div>
                      <div className="text-[11px] text-slate-400">{deal.company}</div>
                    </td>
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-200">
                      {deal.value}
                    </td>
                    <td className="px-4 py-3.5 text-slate-300">
                      {deal.stage}
                    </td>
                    <td className="px-4 py-3.5 text-slate-300">
                      {deal.repName}
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-bold ${
                            isHealthy ? 'text-emerald-400' : 'text-amber-400'
                          }`}
                        >
                          {deal.healthScore}/100
                        </span>
                        <span
                          className={`text-[10px] ${
                            isHealthy ? 'text-emerald-400/80' : 'text-amber-400/80'
                          }`}
                        >
                          · {deal.healthStatus}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 max-w-xs">
                      <div className="text-[11px] text-slate-300 leading-snug">
                        {deal.primaryRisk}
                      </div>
                      {deal.competitor && (
                        <div className="text-[10px] text-rose-300 mt-0.5">
                          Competitor Threat: {deal.competitor}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3.5 max-w-xs text-slate-400 text-[11px]">
                      {deal.nextStep}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <button
                        onClick={() => onSelectDealCall(deal.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-md transition-colors text-[11px] font-medium"
                      >
                        <span>Review</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
