import React from 'react';
import {
  Mic,
  Upload,
  Radio,
  Sparkles,
  BarChart3,
  PhoneCall,
  Users,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import { CallRecord } from '../types';

interface HeaderProps {
  currentCall: CallRecord;
  calls: CallRecord[];
  onSelectCall: (call: CallRecord) => void;
  activeTab: 'intelligence' | 'pipeline' | 'coaching';
  onChangeTab: (tab: 'intelligence' | 'pipeline' | 'coaching') => void;
  onOpenRecorder: () => void;
  onOpenUpload: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentCall,
  calls,
  onSelectCall,
  activeTab,
  onChangeTab,
  onOpenRecorder,
  onOpenUpload,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Info */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Radio className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold tracking-tight text-white">
                    PulseWave
                  </span>
                  <span className="text-[10px] uppercase font-mono tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    Intelligence
                  </span>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">
                  Sales Conversation Intelligence & Coaching
                </p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1 rounded-lg border border-slate-800/80">
              <button
                onClick={() => onChangeTab('intelligence')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  activeTab === 'intelligence'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <PhoneCall className="w-3.5 h-3.5" />
                Call Analysis
              </button>
              <button
                onClick={() => onChangeTab('pipeline')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  activeTab === 'pipeline'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Deal Pipeline
              </button>
              <button
                onClick={() => onChangeTab('coaching')}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  activeTab === 'coaching'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Rep Scorecards
              </button>
            </nav>
          </div>

          {/* Call Selector & Action Buttons */}
          <div className="flex items-center gap-3">
            {/* Active Call Selector */}
            <div className="hidden lg:flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs">
              <span className="text-slate-400">Meeting:</span>
              <select
                value={currentCall.id}
                onChange={(e) => {
                  const found = calls.find((c) => c.id === e.target.value);
                  if (found) onSelectCall(found);
                }}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer max-w-[220px] truncate"
              >
                {calls.map((c) => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-slate-100">
                    {c.prospectCompany} ({c.dealValue}) — {c.repName}
                  </option>
                ))}
              </select>
            </div>

            {/* CRM Integration Status indicator */}
            <div className="hidden xl:flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 rounded-lg px-2.5 py-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>CRM Synced (Salesforce)</span>
            </div>

            {/* Upload Button */}
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700/80 border border-slate-700 rounded-lg transition-colors"
              title="Upload audio or video recording"
            >
              <Upload className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Upload</span>
            </button>

            {/* Live Record Button */}
            <button
              onClick={onOpenRecorder}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 shadow-sm shadow-red-600/30 rounded-lg transition-all"
            >
              <Mic className="w-3.5 h-3.5 animate-pulse" />
              <span>Record Live</span>
            </button>
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="flex md:hidden items-center justify-between py-2 border-t border-slate-800/60 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => onChangeTab('intelligence')}
              className={`px-2.5 py-1 rounded ${
                activeTab === 'intelligence' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Call
            </button>
            <button
              onClick={() => onChangeTab('pipeline')}
              className={`px-2.5 py-1 rounded ${
                activeTab === 'pipeline' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Pipeline
            </button>
            <button
              onClick={() => onChangeTab('coaching')}
              className={`px-2.5 py-1 rounded ${
                activeTab === 'coaching' ? 'bg-indigo-600 text-white' : 'text-slate-400'
              }`}
            >
              Coaching
            </button>
          </div>

          <select
            value={currentCall.id}
            onChange={(e) => {
              const found = calls.find((c) => c.id === e.target.value);
              if (found) onSelectCall(found);
            }}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded px-2 py-1 max-w-[160px] truncate"
          >
            {calls.map((c) => (
              <option key={c.id} value={c.id}>
                {c.prospectCompany}
              </option>
            ))}
          </select>
        </div>
      </div>
    </header>
  );
};
