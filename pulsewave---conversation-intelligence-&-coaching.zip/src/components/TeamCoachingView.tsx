import React from 'react';
import {
  Users,
  Award,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Clock,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { REP_SCORECARDS } from '../data/mockCalls';

export const TeamCoachingView: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Overview Coaching Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white tracking-tight">
              Sales Rep Conversation Coaching & Leaderboard
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Gong Benchmarks Active
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Automated conversation intelligence analysis across rep talk-to-listen ratios, monologue durations, question cadences, and objection handling velocity.
          </p>
        </div>

        {/* Benchmarks Summary Box */}
        <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-lg border border-slate-800/80 text-xs">
          <div>
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Optimal Talk Ratio</span>
            <span className="font-bold text-indigo-400">40% – 45%</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Max Monologue Cap</span>
            <span className="font-bold text-emerald-400">&lt; 150s (2.5m)</span>
          </div>
          <div className="h-6 w-px bg-slate-800" />
          <div>
            <span className="text-[10px] font-mono text-slate-500 uppercase block">Target Questions</span>
            <span className="font-bold text-cyan-400">4.0+ per call</span>
          </div>
        </div>
      </div>

      {/* Rep Scorecards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {REP_SCORECARDS.map((rep, idx) => {
          const isOptimalTalk = rep.avgTalkListen >= 40 && rep.avgTalkListen <= 48;
          return (
            <div
              key={rep.repName}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4 hover:border-slate-700 transition-colors"
            >
              {/* Rep Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={rep.avatar}
                    alt={rep.repName}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-indigo-500/40"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-100 text-sm">{rep.repName}</h3>
                      {idx === 0 && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                          #1 Win Rate
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">{rep.role}</p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-lg font-bold font-mono text-indigo-400">{rep.winRate}%</div>
                  <div className="text-[10px] font-mono text-slate-500 uppercase">Win Rate</div>
                </div>
              </div>

              {/* Rep Conversation Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                  <span className="text-[10px] font-mono text-slate-500 block">Avg Talk Ratio</span>
                  <span
                    className={`font-mono font-bold ${
                      isOptimalTalk ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {rep.avgTalkListen}% Rep
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                  <span className="text-[10px] font-mono text-slate-500 block">Discovery Qs</span>
                  <span className="font-mono font-bold text-cyan-400">
                    {rep.avgQuestionsPerCall} / call
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                  <span className="text-[10px] font-mono text-slate-500 block">Monologue Risk</span>
                  <span
                    className={`font-mono font-bold ${
                      rep.monologueRiskFrequency.includes('Low')
                        ? 'text-emerald-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {rep.monologueRiskFrequency}
                  </span>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                  <span className="text-[10px] font-mono text-slate-500 block">Patience</span>
                  <span className="font-mono font-bold text-indigo-400">
                    {rep.patienceRating} / 10
                  </span>
                </div>
              </div>

              {/* Talk Ratio Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Talk Cadence</span>
                  <span>{rep.avgTalkListen}% Rep / {100 - rep.avgTalkListen}% Buyer</span>
                </div>
                <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                  <div
                    style={{ width: `${rep.avgTalkListen}%` }}
                    className={isOptimalTalk ? 'bg-indigo-500' : 'bg-amber-500'}
                  />
                  <div
                    style={{ width: `${100 - rep.avgTalkListen}%` }}
                    className="bg-emerald-500"
                  />
                </div>
              </div>

              {/* AI Coaching Tip for Manager 1:1 */}
              <div className="p-3 bg-slate-950 rounded-lg border border-indigo-500/20 text-xs">
                <div className="flex items-center gap-1.5 text-indigo-300 font-semibold mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>1:1 Coaching Action Item:</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  {rep.coachTip}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
