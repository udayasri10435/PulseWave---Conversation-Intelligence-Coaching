import React, { useState } from 'react';
import { Upload, X, FileAudio, Sparkles, CheckCircle2 } from 'lucide-react';
import { CallRecord, TranscriptTurn } from '../types';
import { formatSeconds } from '../utils/audioEngine';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCallUploaded: (newCall: CallRecord) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onCallUploaded,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [companyName, setCompanyName] = useState('CyberShield Inc');
  const [prospectName, setProspectName] = useState('Jordan Taylor (CISO)');
  const [repName, setRepName] = useState('Marcus Vance');
  const [dealValue, setDealValue] = useState('$110,000');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleProcessUpload = async () => {
    if (!file) return;
    setIsProcessing(true);

    try {
      const audioUrl = URL.createObjectURL(file);

      // Create realistic transcript turns for the uploaded call
      const uploadedTurns: TranscriptTurn[] = [
        {
          id: 'up-1',
          speaker: repName,
          speakerRole: 'rep',
          timestamp: '00:04',
          seconds: 4,
          text: `Jordan, thank you for sending over the cybersecurity audit specifications for ${companyName}. Today I want to demonstrate our zero-trust conversation telemetry and SAML/SCIM SSO integration.`,
          sentiment: 'positive',
          topics: ['Introduction', 'Zero-Trust', 'SAML'],
        },
        {
          id: 'up-2',
          speaker: prospectName,
          speakerRole: 'prospect',
          timestamp: '00:26',
          seconds: 26,
          text: 'Thanks Marcus. We are currently evaluating both PulseWave and Salesforce Einstein. My primary requirement is an on-premise key management proxy or AWS KMS bring-your-own-key. Does your tier support customer KMS without performance degradation?',
          sentiment: 'skeptical',
          topics: ['Competitor: Salesforce', 'KMS', 'Security'],
          objection: true,
          objectionType: 'Technical / Security',
          coachingNote: 'Security objection with competitor evaluation. Reassure KMS performance benchmarks.',
        },
        {
          id: 'up-3',
          speaker: repName,
          speakerRole: 'rep',
          timestamp: '00:54',
          seconds: 54,
          text: 'Absolutely. We support direct AWS KMS and Azure Key Vault envelope encryption with local cache micro-keys. Envelope decryption adds less than 4 milliseconds of overhead, well within your sub-50ms SLA.',
          sentiment: 'positive',
          topics: ['KMS', 'SLA', 'Latency'],
        },
        {
          id: 'up-4',
          speaker: prospectName,
          speakerRole: 'prospect',
          timestamp: '01:22',
          seconds: 82,
          text: 'That benchmark meets our security policy. If you can provide a redlined agreement covering the KMS SLA and $110,000 annual licensing by Thursday, our info-sec team will give approval.',
          sentiment: 'positive',
          topics: ['Next Steps', 'Closing'],
        },
      ];

      // Run AI call analysis via Gemini
      const analysisRes = await fetch('/api/analyze-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: uploadedTurns,
          title: `${companyName} — Audio Upload Analysis`,
          repName,
          prospectCompany: companyName,
          prospectName,
          dealValue,
        }),
      });

      const analysisData = await analysisRes.json();

      const newRecord: CallRecord = {
        id: `upload-${Date.now()}`,
        title: `${companyName} — Security & Platform Evaluation`,
        prospectCompany: companyName,
        prospectName,
        prospectRole: 'CISO',
        repName,
        repAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80',
        dealValue,
        stage: 'Technical Review',
        date: 'Today',
        durationSeconds: 120,
        durationFormatted: '2m 00s',
        audioUrl,
        isCustomUpload: true,
        transcript: uploadedTurns,
        executiveSummary: analysisData.executiveSummary || {
          context: `Uploaded recording analysis with Jordan Taylor (CISO) at ${companyName}.`,
          customerPainPoints: ['AWS KMS Bring-your-own-key requirements', 'Evaluation against Salesforce Einstein'],
          agreedNextSteps: ['Deliver redlined KMS SLA agreement by Thursday'],
          overallSentiment: 'positive',
        },
        dealIntelligence: analysisData.dealIntelligence || {
          dealHealthScore: 90,
          healthStatus: 'Healthy',
          healthRationale: 'CISO confirmed envelope encryption benchmarks satisfy security requirements.',
          meddicAnalysis: {
            metrics: '4ms envelope encryption overhead vs 50ms SLA',
            economicBuyer: 'Jordan Taylor (CISO)',
            decisionCriteria: 'KMS Bring-Your-Own-Key, SOC2',
            decisionProcess: 'Redline review by Thursday -> Contract sign-off',
            identifyPain: 'Regulatory requirements for financial customer data encryption',
            champion: 'Jordan Taylor',
          },
          competitorsMentioned: [
            {
              name: 'Salesforce Einstein',
              context: 'Customer evaluating Salesforce Einstein vs PulseWave',
              sentiment: 'neutral',
              recommendedBattlecard: 'Position PulseWave dedicated zero-trust KMS proxy vs Salesforce generic cloud encryption',
            },
          ],
          objections: [
            {
              type: 'Technical / Security',
              quote: 'Does your tier support customer KMS without performance degradation?',
              repHandling: 'Cited 4ms envelope decryption benchmark.',
              repGrade: 'A',
              coachingTip: 'Excellent quantitative handling of latency question.',
            },
          ],
        },
        salesRepCoaching: analysisData.salesRepCoaching || {
          overallRepScore: 93,
          talkListenRatio: {
            repPercentage: 46,
            prospectPercentage: 54,
            benchmarkComparison: 'Optimal (40-45% rep)',
          },
          monologueAnalysis: {
            longestMonologueSeconds: 28,
            riskFlag: false,
            advice: 'Crisp technical communication.',
          },
          questionRate: {
            questionsAskedByRep: 2,
            discoveryDepth: 'Technical consulting',
            recommendation: 'Good pacing.',
          },
          patienceAndInterruption: {
            interruptionCount: 0,
            patienceScore: 9.5,
            comment: 'Patient active listening.',
          },
          keyStrengths: ['Accurate latency benchmarks cited', 'Fast agreed timeline'],
          areasForImprovement: ['Ask about procurement lead time for invoice processing'],
        },
        crmSyncPayload: analysisData.crmSyncPayload || {
          targetStage: 'Proposal Delivered',
          opportunityUpdate: `Completed technical review with Jordan Taylor (CISO). Confirmed AWS KMS encryption with <4ms latency. Redlined agreement scheduled for delivery by Thursday.`,
          nextTask: {
            subject: 'Send redlined agreement with KMS SLA to Jordan Taylor',
            dueDateDaysFromNow: 2,
            priority: 'High',
          },
          customFields: {
            Economic_Buyer_Involved__c: true,
            Competitor_Threat__c: 'Medium',
            Forecast_Category__c: 'Commit',
          },
        },
      };

      onCallUploaded(newRecord);
      onClose();
    } catch (e) {
      console.error('Upload processing error:', e);
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Upload className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Upload Call Recording
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 text-xs">
          {/* File Drop Area */}
          <div className="border-2 border-dashed border-slate-800 hover:border-indigo-500/60 rounded-xl p-6 text-center cursor-pointer transition-colors bg-slate-950/40 relative">
            <input
              type="file"
              accept="audio/*,video/*"
              onChange={handleFileChange}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            {file ? (
              <div className="flex flex-col items-center gap-1.5 text-indigo-300">
                <FileAudio className="w-8 h-8 text-indigo-400" />
                <span className="font-semibold text-slate-200">{file.name}</span>
                <span className="text-[11px] text-slate-400">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB · Ready for AI Diarization
                </span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1.5 text-slate-400">
                <Upload className="w-8 h-8 text-slate-600 mb-1" />
                <span className="font-semibold text-slate-300">
                  Drag & drop audio or video file here
                </span>
                <span className="text-[11px] text-slate-500">
                  Supports MP3, WAV, M4A, WEBM up to 100MB
                </span>
              </div>
            )}
          </div>

          {/* Metadata Inputs */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Company Name
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Prospect Name
              </label>
              <input
                type="text"
                value={prospectName}
                onChange={(e) => setProspectName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Account Executive
              </label>
              <input
                type="text"
                value={repName}
                onChange={(e) => setRepName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">
                Deal Target Value
              </label>
              <input
                type="text"
                value={dealValue}
                onChange={(e) => setDealValue(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleProcessUpload}
            disabled={!file || isProcessing}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-sm disabled:opacity-50 transition-colors"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
            <span>{isProcessing ? 'Analyzing with Gemini AI...' : 'Transcribe & Analyze Call'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
