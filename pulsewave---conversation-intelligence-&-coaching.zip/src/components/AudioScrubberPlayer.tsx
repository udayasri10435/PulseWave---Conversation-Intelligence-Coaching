import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Bookmark,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { CallRecord, TranscriptTurn } from '../types';
import { formatSeconds } from '../utils/audioEngine';

interface AudioScrubberPlayerProps {
  currentCall: CallRecord;
  currentTime: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  onSkip: (delta: number) => void;
  playbackRate: number;
  onChangePlaybackRate: (rate: number) => void;
}

export const AudioScrubberPlayer: React.FC<AudioScrubberPlayerProps> = ({
  currentCall,
  currentTime,
  isPlaying,
  onTogglePlay,
  onSeek,
  onSkip,
  playbackRate,
  onChangePlaybackRate,
}) => {
  const progressBarRef = useRef<HTMLDivElement>(null);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState<number>(0);
  const [isMuted, setIsMuted] = useState(false);

  const duration = currentCall.durationSeconds || 1;
  const progressPercent = Math.min(100, Math.max(0, (currentTime / duration) * 100));

  // Determine currently speaking turn
  const currentTurn = currentCall.transcript.reduce<TranscriptTurn | null>(
    (acc, turn) => {
      if (currentTime >= turn.seconds) {
        return turn;
      }
      return acc;
    },
    null
  ) || currentCall.transcript[0];

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickRatio = Math.max(0, Math.min(1, clickX / rect.width));
    onSeek(clickRatio * duration);
  };

  const handleProgressBarMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const moveX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, moveX / rect.width));
    setHoverTime(ratio * duration);
    setHoverPosition(moveX);
  };

  const handleProgressBarMouseLeave = () => {
    setHoverTime(null);
  };

  // Generate simulated waveform segments for visual aesthetic
  const waveformBars = React.useMemo(() => {
    const barsCount = 120;
    const bars = [];
    for (let i = 0; i < barsCount; i++) {
      const secondAtBar = (i / barsCount) * duration;
      // find which speaker is active at this second
      let speakerRole = 'rep';
      for (const turn of currentCall.transcript) {
        if (secondAtBar >= turn.seconds) {
          speakerRole = turn.speakerRole;
        }
      }
      // calculate semi-random height based on index hash for realistic voice energy
      const pseudoHeight = Math.sin(i * 0.4) * 0.35 + Math.cos(i * 0.9) * 0.25 + 0.5;
      const heightPercent = Math.max(20, Math.min(95, pseudoHeight * 85));
      bars.push({
        secondAtBar,
        speakerRole,
        heightPercent,
      });
    }
    return bars;
  }, [currentCall.id, duration]);

  // Objections timeline markers
  const objectionTurns = currentCall.transcript.filter((t) => t.objection);

  return (
    <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-4 shadow-xl">
      <div className="max-w-7xl mx-auto flex flex-col gap-3">
        {/* Top Info Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={currentCall.repAvatar}
                alt={currentCall.repName}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/40"
              />
              {isPlaying && (
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-900 animate-ping" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-semibold text-white tracking-tight">
                  {currentCall.title}
                </h1>
                <span className="text-xs font-semibold text-indigo-400">
                  {currentCall.dealValue}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="text-slate-300 font-medium">{currentCall.repName}</span>
                <span aria-hidden="true">·</span>
                <span>{currentCall.prospectName} ({currentCall.prospectRole})</span>
                <span aria-hidden="true">·</span>
                <span>{currentCall.date}</span>
              </div>
            </div>
          </div>

          {/* Quick Metrics Bar: Talk Ratio & Score */}
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Talk:Listen</span>
              <div className="flex items-center gap-1 font-mono font-medium">
                <span className="text-indigo-400">
                  {currentCall.salesRepCoaching.talkListenRatio.repPercentage}% Rep
                </span>
                <span className="text-slate-500">/</span>
                <span className="text-emerald-400">
                  {currentCall.salesRepCoaching.talkListenRatio.prospectPercentage}% Buyer
                </span>
              </div>
            </div>

            <div className="h-4 w-px bg-slate-800" />

            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">Deal Health:</span>
              <span
                className={`font-semibold ${
                  currentCall.dealIntelligence.dealHealthScore >= 80
                    ? 'text-emerald-400'
                    : currentCall.dealIntelligence.dealHealthScore >= 60
                    ? 'text-amber-400'
                    : 'text-red-400'
                }`}
              >
                {currentCall.dealIntelligence.dealHealthScore}/100 ({currentCall.dealIntelligence.healthStatus})
              </span>
            </div>
          </div>
        </div>

        {/* Waveform Scrubber Track */}
        <div className="relative pt-2">
          {/* Tooltip on Hover */}
          {hoverTime !== null && (
            <div
              className="absolute -top-7 transform -translate-x-1/2 pointer-events-none bg-slate-800 text-slate-200 text-[11px] font-mono px-2 py-0.5 rounded shadow-lg border border-slate-700 z-20 whitespace-nowrap"
              style={{ left: `${hoverPosition}px` }}
            >
              {formatSeconds(hoverTime)}
            </div>
          )}

          {/* Interactive Scrub Bar Area */}
          <div
            ref={progressBarRef}
            onClick={handleProgressBarClick}
            onMouseMove={handleProgressBarMouseMove}
            onMouseLeave={handleProgressBarMouseLeave}
            className="group relative h-14 bg-slate-950 rounded-lg p-1.5 border border-slate-800/80 cursor-pointer overflow-hidden select-none"
          >
            {/* Waveform Bars */}
            <div className="flex items-center justify-between h-full gap-[2px]">
              {waveformBars.map((bar, idx) => {
                const isPast = (bar.secondAtBar / duration) * 100 <= progressPercent;
                const isRep = bar.speakerRole === 'rep';

                let barColor = 'bg-slate-800';
                if (isPast) {
                  barColor = isRep ? 'bg-indigo-500' : 'bg-emerald-400';
                } else {
                  barColor = isRep ? 'bg-slate-700/60' : 'bg-slate-700/40';
                }

                return (
                  <div
                    key={idx}
                    className="flex-1 flex items-center justify-center h-full"
                  >
                    <div
                      style={{ height: `${bar.heightPercent}%` }}
                      className={`w-full max-w-[4px] rounded-full transition-colors duration-100 ${barColor}`}
                    />
                  </div>
                );
              })}
            </div>

            {/* Playhead Progress Overlay Line */}
            <div
              className="absolute top-0 bottom-0 w-[2px] bg-cyan-400 shadow-[0_0_10px_#22d3ee] pointer-events-none transition-all duration-75"
              style={{ left: `${progressPercent}%` }}
            >
              <div className="w-3 h-3 bg-cyan-400 rounded-full -ml-[5px] -mt-[3px] shadow-sm shadow-cyan-400/50" />
            </div>

            {/* Objection Markers along the track */}
            {objectionTurns.map((obj) => {
              const markerPercent = (obj.seconds / duration) * 100;
              return (
                <div
                  key={obj.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(obj.seconds);
                  }}
                  className="absolute bottom-1 -translate-x-1/2 group/marker z-10 cursor-pointer"
                  style={{ left: `${markerPercent}%` }}
                  title={`${obj.timestamp} Objection: ${obj.objectionType || 'Price/Timing'}`}
                >
                  <div className="w-2.5 h-2.5 rotate-45 bg-amber-400 ring-2 ring-slate-900 group-hover/marker:scale-125 transition-transform" />
                  <div className="hidden group-hover/marker:block absolute bottom-5 left-1/2 -translate-x-1/2 bg-slate-900 border border-amber-500/40 text-amber-200 text-[10px] px-2 py-1 rounded shadow-xl whitespace-nowrap">
                    Objection: {obj.objectionType} ({obj.timestamp})
                  </div>
                </div>
              );
            })}
          </div>

          {/* Speaker Segment Legend */}
          <div className="flex items-center justify-between mt-1 text-[11px] text-slate-500">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-500" />
                <span className="text-slate-400">Rep: {currentCall.repName}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-slate-400">Buyer: {currentCall.prospectName}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rotate-45 bg-amber-400" />
                <span className="text-slate-400">Objection marker</span>
              </span>
            </div>
            <div className="font-mono text-slate-400">
              {formatSeconds(currentTime)} / {currentCall.durationFormatted}
            </div>
          </div>
        </div>

        {/* Playback Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-1 border-t border-slate-800/60">
          {/* Active Speaking Turn Preview */}
          <div className="flex items-center gap-2 max-w-sm sm:max-w-md truncate text-xs">
            <span className="text-slate-500 font-medium">Active:</span>
            <span
              className={`font-semibold ${
                currentTurn?.speakerRole === 'rep' ? 'text-indigo-400' : 'text-emerald-400'
              }`}
            >
              {currentTurn?.speaker}:
            </span>
            <span className="text-slate-300 truncate italic">
              "{currentTurn?.text}"
            </span>
          </div>

          {/* Controls: Play/Pause, Rewind, Fast Forward, Speed */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSkip(-10)}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              title="Rewind 10 seconds"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={onTogglePlay}
              className="w-9 h-9 flex items-center justify-center bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-lg shadow-indigo-600/30 transition-all transform active:scale-95"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-white" />
              ) : (
                <Play className="w-4 h-4 fill-white translate-x-0.5" />
              )}
            </button>

            <button
              onClick={() => onSkip(10)}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              title="Skip 10 seconds"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* Speed Selector */}
            <div className="flex items-center ml-2 bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px] font-mono">
              {[1, 1.25, 1.5, 2].map((rate) => (
                <button
                  key={rate}
                  onClick={() => onChangePlaybackRate(rate)}
                  className={`px-1.5 py-0.5 rounded transition-colors ${
                    playbackRate === rate
                      ? 'bg-indigo-600 text-white font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>

            {/* Mute button */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors ml-1"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
