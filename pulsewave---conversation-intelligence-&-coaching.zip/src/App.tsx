import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { AudioScrubberPlayer } from './components/AudioScrubberPlayer';
import { TranscriptViewer } from './components/TranscriptViewer';
import { SidecarIntelligence } from './components/SidecarIntelligence';
import { DealPipelineView } from './components/DealPipelineView';
import { TeamCoachingView } from './components/TeamCoachingView';
import { LiveRecorderModal } from './components/LiveRecorderModal';
import { UploadModal } from './components/UploadModal';
import { INITIAL_CALLS } from './data/mockCalls';
import { CallRecord } from './types';
import { CallPlaybackController } from './utils/audioEngine';

export default function App() {
  const [calls, setCalls] = useState<CallRecord[]>(INITIAL_CALLS);
  const [currentCall, setCurrentCall] = useState<CallRecord>(INITIAL_CALLS[0]);
  const [activeTab, setActiveTab] = useState<'intelligence' | 'pipeline' | 'coaching'>('intelligence');

  // Playback state
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);

  // Modals
  const [isRecorderOpen, setIsRecorderOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  // Audio Playback Controller
  const playerRef = useRef<CallPlaybackController | null>(null);

  if (!playerRef.current) {
    playerRef.current = new CallPlaybackController();
  }

  // Setup callbacks and load call
  useEffect(() => {
    const player = playerRef.current;
    if (!player) return;

    player.setOnTimeUpdate((time) => {
      setCurrentTime(time);
    });

    player.setOnStateChange((playing) => {
      setIsPlaying(playing);
    });

    player.loadCall(
      currentCall.transcript,
      currentCall.durationSeconds,
      currentCall.audioUrl
    );
    player.setPlaybackRate(playbackRate);
    setCurrentTime(0);
    setIsPlaying(false);

    return () => {
      player.stop();
    };
  }, [currentCall.id]);

  const handleTogglePlay = () => {
    playerRef.current?.togglePlay();
  };

  const handleSeek = (seconds: number) => {
    playerRef.current?.seek(seconds);
  };

  const handleSkip = (delta: number) => {
    playerRef.current?.skip(delta);
  };

  const handleChangePlaybackRate = (rate: number) => {
    setPlaybackRate(rate);
    playerRef.current?.setPlaybackRate(rate);
  };

  const handleUpdateCall = (updated: CallRecord) => {
    setCurrentCall(updated);
    setCalls((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  const handleCallRecordedOrUploaded = (newCall: CallRecord) => {
    setCalls((prev) => [newCall, ...prev]);
    setCurrentCall(newCall);
    setActiveTab('intelligence');
  };

  const handleSelectDealFromPipeline = (dealId: string) => {
    // Select the corresponding call or default to first
    const matched = calls.find((c) => c.dealValue === '$140,000') || calls[0];
    setCurrentCall(matched);
    setActiveTab('intelligence');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        currentCall={currentCall}
        calls={calls}
        onSelectCall={(call) => setCurrentCall(call)}
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
        onOpenRecorder={() => setIsRecorderOpen(true)}
        onOpenUpload={() => setIsUploadOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'intelligence' && (
          <div className="flex-1 flex flex-col">
            {/* Hero Audio Waveform Scrubber */}
            <AudioScrubberPlayer
              currentCall={currentCall}
              currentTime={currentTime}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onSeek={handleSeek}
              onSkip={handleSkip}
              playbackRate={playbackRate}
              onChangePlaybackRate={handleChangePlaybackRate}
            />

            {/* Main Dual Columns: Transcript & Sidecar Intelligence */}
            <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 grid grid-cols-1 lg:grid-cols-12 gap-5 min-h-[620px]">
              {/* Left Column: Synchronized Transcript */}
              <div className="lg:col-span-7 h-[680px]">
                <TranscriptViewer
                  transcript={currentCall.transcript}
                  currentTime={currentTime}
                  onSeek={handleSeek}
                  repName={currentCall.repName}
                />
              </div>

              {/* Right Column: Gong/Chorus Sidecar Intelligence */}
              <div className="lg:col-span-5 h-[680px]">
                <SidecarIntelligence
                  call={currentCall}
                  onUpdateCall={handleUpdateCall}
                  onSeek={handleSeek}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'pipeline' && (
          <DealPipelineView
            calls={calls}
            onSelectDealCall={handleSelectDealFromPipeline}
          />
        )}

        {activeTab === 'coaching' && <TeamCoachingView />}
      </main>

      {/* Live Recorder Modal */}
      <LiveRecorderModal
        isOpen={isRecorderOpen}
        onClose={() => setIsRecorderOpen(false)}
        onCallRecorded={handleCallRecordedOrUploaded}
      />

      {/* Audio Upload Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onCallUploaded={handleCallRecordedOrUploaded}
      />
    </div>
  );
}
