import { TranscriptTurn } from '../types';

export class CallPlaybackController {
  private transcript: TranscriptTurn[] = [];
  private currentTime: number = 0;
  private duration: number = 0;
  private isPlaying: boolean = false;
  private playbackRate: number = 1.0;
  private audioEl: HTMLAudioElement | null = null;
  private timer: number | null = null;
  private onTimeUpdateCallback: ((time: number) => void) | null = null;
  private onStateChangeCallback: ((playing: boolean) => void) | null = null;
  private audioContext: AudioContext | null = null;
  private activeOscillator: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;

  constructor() {}

  public loadCall(
    transcript: TranscriptTurn[],
    durationSeconds: number,
    audioUrl?: string
  ) {
    this.stop();
    this.transcript = transcript;
    this.duration = durationSeconds;
    this.currentTime = 0;

    if (audioUrl) {
      if (this.audioEl) {
        this.audioEl.pause();
        this.audioEl.src = '';
      }
      this.audioEl = new Audio(audioUrl);
      this.audioEl.playbackRate = this.playbackRate;
      this.audioEl.ontimeupdate = () => {
        if (this.audioEl) {
          this.currentTime = this.audioEl.currentTime;
          this.onTimeUpdateCallback?.(this.currentTime);
        }
      };
      this.audioEl.onended = () => {
        this.pause();
      };
    } else {
      this.audioEl = null;
    }
  }

  public setOnTimeUpdate(cb: (time: number) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public setOnStateChange(cb: (playing: boolean) => void) {
    this.onStateChangeCallback = cb;
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    if (this.audioEl) {
      this.audioEl.playbackRate = rate;
    }
  }

  public play() {
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.onStateChangeCallback?.(true);

    if (this.audioEl) {
      this.audioEl.play().catch((e) => console.log('Audio play error', e));
    } else {
      // Synthetic realistic simulation timer
      const intervalMs = 100;
      this.timer = window.setInterval(() => {
        this.currentTime += (intervalMs / 1000) * this.playbackRate;
        if (this.currentTime >= this.duration) {
          this.currentTime = this.duration;
          this.pause();
        }
        this.onTimeUpdateCallback?.(this.currentTime);
      }, intervalMs);
    }
  }

  public pause() {
    this.isPlaying = false;
    this.onStateChangeCallback?.(false);
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.audioEl) {
      this.audioEl.pause();
    }
  }

  public togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  public seek(seconds: number) {
    const clamped = Math.max(0, Math.min(seconds, this.duration));
    this.currentTime = clamped;
    if (this.audioEl) {
      this.audioEl.currentTime = clamped;
    }
    this.onTimeUpdateCallback?.(this.currentTime);
  }

  public skip(secondsDelta: number) {
    this.seek(this.currentTime + secondsDelta);
  }

  public stop() {
    this.pause();
    this.currentTime = 0;
    this.onTimeUpdateCallback?.(0);
  }

  public getCurrentTime(): number {
    return this.currentTime;
  }

  public getDuration(): number {
    return this.duration;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export function formatSeconds(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}
